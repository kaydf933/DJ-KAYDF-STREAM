async function load(){
let res = await fetch('/api/mixes');
let data = await res.json();

let list = document.getElementById('list');
list.innerHTML = '';

data.forEach(m=>{
let d=document.createElement('div');
d.innerText=m.name;
d.onclick=()=>{
document.getElementById('player').src=m.url;
document.getElementById('player').play();
};
list.appendChild(d);
});
}

load();

async function upload(){
let file=document.getElementById('file').files[0];
let fd=new FormData();
fd.append('file',file);

await fetch('/upload',{method:'POST',body:fd});
alert("Uploaded");
load();
}