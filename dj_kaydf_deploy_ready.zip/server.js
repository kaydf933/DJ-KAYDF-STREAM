const express = require("express");
const multer = require("multer");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});

const upload = multer({ storage });

if (!fs.existsSync("uploads")) fs.mkdirSync("uploads");

app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));

app.get("/api/mixes", (req, res) => {
  const files = fs.readdirSync("uploads");
  res.json(files.map(f => ({ name: f, url: "/uploads/" + f })));
});

app.post("/upload", upload.single("file"), (req, res) => {
  res.json({ success: true });
});

app.listen(PORT, () => console.log("Server running on " + PORT));